
import React from 'react';
import type { NewsArticle } from '../types';

interface NewsCardProps {
  article: NewsArticle;
}

const NewsCard: React.FC<NewsCardProps> = ({ article }) => {
  const articleDate = new Date(article.date);
  const formattedDate = articleDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="bg-slate-800 rounded-lg shadow-lg overflow-hidden transition-transform transform hover:-translate-y-1">
      <img className="h-48 w-full object-cover" src={article.imageUrl} alt={article.title} />
      <div className="p-6">
        <p className="text-sm text-slate-400">{article.author} &middot; {formattedDate}</p>
        <h3 className="mt-2 text-xl font-bold text-white leading-tight">{article.title}</h3>
        <p className="mt-3 text-slate-300">{article.snippet}</p>
        <button className="mt-4 text-sky-400 hover:text-sky-300 font-semibold text-sm">
          Read More &rarr;
        </button>
      </div>
    </div>
  );
};

export default NewsCard;
