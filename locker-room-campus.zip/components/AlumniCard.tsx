
import React from 'react';
import type { Alumni } from '../types';

interface AlumniCardProps {
  alumni: Alumni;
}

const AlumniCard: React.FC<AlumniCardProps> = ({ alumni }) => {
  return (
    <div className="bg-slate-800 rounded-lg p-4 flex flex-col items-center text-center shadow-lg transition-transform transform hover:-translate-y-1">
      <img className="w-24 h-24 rounded-full mb-4 border-2 border-slate-600" src={alumni.avatarUrl} alt={alumni.name} />
      <h3 className="text-lg font-bold text-white">{alumni.name}</h3>
      <p className="text-slate-400">{alumni.sport} Alum &apos;{alumni.graduationYear.toString().slice(-2)}</p>
      <p className="text-sm text-slate-500 mt-1">{alumni.profession} at {alumni.company}</p>
      <button className="mt-4 w-full bg-slate-700 text-white py-2 px-4 rounded-md text-sm font-semibold hover:bg-slate-600 transition-colors">
        Get Intro
      </button>
    </div>
  );
};

export default AlumniCard;
