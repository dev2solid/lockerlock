import React from 'react';

interface VerifiedIconProps extends React.SVGProps<SVGSVGElement> {
  title?: string;
}

const VerifiedIcon: React.FC<VerifiedIconProps> = ({ title, ...props }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    {title && <title>{title}</title>}
    <path fillRule="evenodd" d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12c0 1.357-.6 2.573-1.549 3.397a4.49 4.49 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.491 4.491 0 013.497-1.307zm3.169 7.423a.75.75 0 01.044 1.06l-4.25 4.5a.75.75 0 01-1.1-.984l4.25-4.5a.75.75 0 011.056-.076zm-2.23-2.67a.75.75 0 10-1.06-1.06l-2.25 2.25a.75.75 0 001.06 1.06l2.25-2.25z" clipRule="evenodd" />
  </svg>
);

export default VerifiedIcon;
