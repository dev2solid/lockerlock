
import React from 'react';
import { useLocation } from 'react-router-dom';
import { SearchIcon } from './icons/SearchIcon';

const Header: React.FC = () => {
  const location = useLocation();

  const getTitle = () => {
    const path = location.pathname.split('/')[1];
    if (!path) return 'Dashboard';
    return path.charAt(0).toUpperCase() + path.slice(1);
  };

  return (
    <header className="flex-shrink-0 bg-slate-800 border-b border-slate-700">
      <div className="flex items-center justify-between h-20 px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-bold text-white">{getTitle()}</h1>
        <div className="flex items-center">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-5 w-5 text-slate-500" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-slate-700 rounded-md leading-5 bg-slate-900 text-slate-200 placeholder-slate-500 focus:outline-none focus:placeholder-slate-400 focus:ring-1 focus:ring-sky-500 focus:border-sky-500 sm:text-sm"
              placeholder="Search..."
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
