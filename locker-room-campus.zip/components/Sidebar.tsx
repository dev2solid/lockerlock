
import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import HomeIcon from './icons/HomeIcon';
import UsersIcon from './icons/UsersIcon';
import AlumniIcon from './icons/AlumniIcon';
import CalendarIcon from './icons/CalendarIcon';
import NewspaperIcon from './icons/NewspaperIcon';
import LogoutIcon from './icons/LogoutIcon';
import Logo from './icons/Logo';

const Sidebar: React.FC = () => {
    const { logout, user } = useAuth();

    const navigation = [
        { name: 'Dashboard', href: '/dashboard', icon: HomeIcon },
        { name: 'Athletes', href: '/athletes', icon: UsersIcon },
        { name: 'Alumni', href: '/alumni', icon: AlumniIcon },
        { name: 'Events', href: '/events', icon: CalendarIcon },
        { name: 'News', href: '/news', icon: NewspaperIcon },
    ];

    const NavItem: React.FC<{item: typeof navigation[0]}> = ({ item }) => (
         <NavLink
            to={item.href}
            className={({ isActive }) =>
                `flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 ${
                isActive
                    ? 'bg-slate-700 text-white'
                    : 'text-slate-400 hover:bg-slate-700 hover:text-white'
                }`
            }
        >
            <item.icon className="h-5 w-5 mr-3" />
            {item.name}
        </NavLink>
    );


  return (
    <div className="flex flex-col w-64 bg-slate-800 border-r border-slate-700">
      <div className="flex items-center justify-center h-20 border-b border-slate-700">
        <Logo className="h-8 w-8 text-sky-500" />
        <span className="ml-3 text-xl font-bold text-white">Locker Room</span>
      </div>
      <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
        <nav className="flex-1 px-3 space-y-2">
            {navigation.map((item) => <NavItem key={item.name} item={item} />)}
        </nav>
      </div>
      <div className="flex-shrink-0 flex border-t border-slate-700 p-4">
        <div className="flex-shrink-0 w-full group block">
            <div className="flex items-center">
                <img className="inline-block h-10 w-10 rounded-full" src={user?.avatarUrl} alt="" />
                <div className="ml-3">
                    <p className="text-sm font-medium text-white">{user?.name}</p>
                    <p className="text-xs font-medium text-slate-400">{user?.sport}</p>
                </div>
                <button onClick={logout} className="ml-auto p-2 rounded-md text-slate-400 hover:bg-slate-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-white">
                    <LogoutIcon className="h-5 w-5" />
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
