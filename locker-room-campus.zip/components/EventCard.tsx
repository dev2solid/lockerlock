
import React from 'react';
import type { CampusEvent } from '../types';
import CalendarIcon from './icons/CalendarIcon';

interface EventCardProps {
  event: CampusEvent;
}

const EventCard: React.FC<EventCardProps> = ({ event }) => {
  const eventDate = new Date(event.date);
  const formattedDate = eventDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  const formattedTime = eventDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });

  const typeColorMap = {
    'Workshop': 'bg-blue-500',
    'Social': 'bg-purple-500',
    'Career Fair': 'bg-green-500',
    'Game Day': 'bg-red-500'
  };

  return (
    <div className="bg-slate-800 rounded-lg shadow-lg overflow-hidden flex flex-col">
      <div className="p-5 flex-grow">
        <div className="flex justify-between items-start">
            <div>
                 <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${typeColorMap[event.type]} text-white`}>
                    {event.type}
                </span>
                <h3 className="mt-2 text-xl font-bold text-white">{event.title}</h3>
            </div>
            <div className="flex flex-col items-center justify-center bg-slate-700 rounded-md p-2 text-center w-16 h-16">
                <span className="text-white font-bold text-2xl">{formattedDate.split(' ')[1]}</span>
                <span className="text-slate-300 text-xs uppercase">{formattedDate.split(' ')[0]}</span>
            </div>
        </div>
        <p className="mt-2 text-slate-400 text-sm">{event.description}</p>
      </div>
      <div className="bg-slate-800/50 border-t border-slate-700 px-5 py-3 flex justify-between items-center">
         <div className="flex items-center text-sm text-slate-400">
            <CalendarIcon className="w-4 h-4 mr-2" />
            <span>{formattedTime} &middot; {event.location}</span>
        </div>
        <button className="bg-sky-600 text-white py-1.5 px-4 rounded-md text-sm font-semibold hover:bg-sky-500 transition-colors">
          RSVP
        </button>
      </div>
    </div>
  );
};

export default EventCard;
