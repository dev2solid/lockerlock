
import React from 'react';
import type { Athlete } from '../types';
import VerifiedIcon from './icons/VerifiedIcon';

interface AthleteCardProps {
  athlete: Athlete;
}

const AthleteCard: React.FC<AthleteCardProps> = ({ athlete }) => {
  return (
    <div className="bg-slate-800 rounded-lg p-4 flex flex-col items-center text-center shadow-lg transition-transform transform hover:-translate-y-1">
      <img className="w-24 h-24 rounded-full mb-4 border-2 border-slate-600" src={athlete.avatarUrl} alt={athlete.name} />
      <div className="flex items-center gap-2">
        <h3 className="text-lg font-bold text-white">{athlete.name}</h3>
        {athlete.isVerified && <VerifiedIcon className="w-5 h-5 text-amber-400" title="Verified Athlete"/>}
      </div>
      <p className="text-slate-400">{athlete.sport}</p>
      <p className="text-sm text-slate-500 mt-1">Class of {athlete.year} &middot; {athlete.major}</p>
      <button className="mt-4 w-full bg-sky-600 text-white py-2 px-4 rounded-md text-sm font-semibold hover:bg-sky-500 transition-colors">
        Connect
      </button>
    </div>
  );
};

export default AthleteCard;
