
import type { User, Athlete, Alumni, CampusEvent, NewsArticle } from '../types';

export const mockUser: User = {
  id: 'user-1',
  name: 'Alex Morgan',
  email: 'alex.morgan@university.edu',
  avatarUrl: 'https://picsum.photos/seed/user1/100/100',
  isVerified: true,
  sport: 'Soccer',
};

export const athletes: Athlete[] = [
  { id: 'ath-1', name: 'Jordan Lee', sport: 'Basketball', year: 2025, major: 'Business', avatarUrl: 'https://picsum.photos/seed/ath1/100/100', isVerified: true },
  { id: 'ath-2', name: 'Maria Garcia', sport: 'Volleyball', year: 2024, major: 'Kinesiology', avatarUrl: 'https://picsum.photos/seed/ath2/100/100', isVerified: false },
  { id: 'ath-3', name: 'Sam Chen', sport: 'Swimming', year: 2026, major: 'Computer Science', avatarUrl: 'https://picsum.photos/seed/ath3/100/100', isVerified: true },
  { id: 'ath-4', name: 'Emily White', sport: 'Track & Field', year: 2025, major: 'Psychology', avatarUrl: 'https://picsum.photos/seed/ath4/100/100', isVerified: false },
  { id: 'ath-5', name: 'David Kim', sport: 'Football', year: 2024, major: 'Economics', avatarUrl: 'https://picsum.photos/seed/ath5/100/100', isVerified: true },
  { id: 'ath-6', name: 'Chloe Taylor', sport: 'Tennis', year: 2027, major: 'Communications', avatarUrl: 'https://picsum.photos/seed/ath6/100/100', isVerified: false },
  { id: 'ath-7', name: 'Ben Carter', sport: 'Baseball', year: 2025, major: 'History', avatarUrl: 'https://picsum.photos/seed/ath7/100/100', isVerified: true },
  { id: 'ath-8', name: 'Olivia Rodriguez', sport: 'Soccer', year: 2026, major: 'Biology', avatarUrl: 'https://picsum.photos/seed/ath8/100/100', isVerified: true },
];

export const alumni: Alumni[] = [
  { id: 'alu-1', name: 'Michael Johnson', sport: 'Track & Field', graduationYear: 2010, profession: 'Software Engineer', company: 'Google', avatarUrl: 'https://picsum.photos/seed/alu1/100/100' },
  { id: 'alu-2', name: 'Jessica Miller', sport: 'Basketball', graduationYear: 2015, profession: 'Marketing Manager', company: 'Nike', avatarUrl: 'https://picsum.photos/seed/alu2/100/100' },
  { id: 'alu-3', name: 'Chris Davis', sport: 'Football', graduationYear: 2012, profession: 'Financial Analyst', company: 'Goldman Sachs', avatarUrl: 'https://picsum.photos/seed/alu3/100/100' },
  { id: 'alu-4', name: 'Sarah Brown', sport: 'Swimming', graduationYear: 2018, profession: 'Physical Therapist', company: 'Stanford Health Care', avatarUrl: 'https://picsum.photos/seed/alu4/100/100' },
  { id: 'alu-5', name: 'Kevin Wilson', sport: 'Baseball', graduationYear: 2011, profession: 'Sports Agent', company: 'CAA Sports', avatarUrl: 'https://picsum.photos/seed/alu5/100/100' },
  { id: 'alu-6', name: 'Rachel Green', sport: 'Volleyball', graduationYear: 2019, profession: 'UX Designer', company: 'Adobe', avatarUrl: 'https://picsum.photos/seed/alu6/100/100' },
];

export const events: CampusEvent[] = [
  { id: 'evt-1', title: 'Athlete Career Workshop', date: '2024-10-15T18:00:00Z', location: 'Alumni Center', description: 'Connect with alumni and learn how to leverage your athletic experience in your career.', type: 'Workshop' },
  { id: 'evt-2', title: 'End-of-Season BBQ', date: '2024-11-05T17:00:00Z', location: 'Campus Green', description: 'Celebrate a great season with food, games, and music. All teams welcome!', type: 'Social' },
  { id: 'evt-3', title: 'Tech Industry Networking Night', date: '2024-11-20T19:00:00Z', location: 'Engineering Hall', description: 'Meet recruiters and professionals from top tech companies.', type: 'Career Fair' },
  { id: 'evt-4', title: 'Homecoming Tailgate', date: '2024-10-26T12:00:00Z', location: 'Stadium Parking Lot', description: 'Get hyped for the big game with the official all-athlete tailgate party.', type: 'Game Day'},
];

export const news: NewsArticle[] = [
  { id: 'nws-1', title: 'New Strength & Conditioning Center Opens', author: 'Campus Athletics Dept.', date: '2024-09-01T09:00:00Z', snippet: 'The state-of-the-art facility is now open to all student-athletes, featuring brand new equipment and expanded training spaces.', imageUrl: 'https://picsum.photos/seed/news1/400/200' },
  { id: 'nws-2', title: 'Navigating NIL: A Guide for Student-Athletes', author: 'Compliance Office', date: '2024-08-25T14:00:00Z', snippet: 'As the landscape of college sports evolves, get up to speed on the latest Name, Image, and Likeness (NIL) policies and opportunities.', imageUrl: 'https://picsum.photos/seed/news2/400/200' },
  { id: 'nws-3', title: 'Volleyball Team Secures Conference Championship', author: 'Sports Information', date: '2024-08-28T21:00:00Z', snippet: 'A stunning victory last night clinched the title for our women\'s volleyball team. Read the full game recap here.', imageUrl: 'https://picsum.photos/seed/news3/400/200' },
];
