
export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl: string;
  isVerified: boolean;
  sport: string;
}

export interface Athlete {
  id: string;
  name: string;
  sport: string;
  year: number;
  major: string;
  avatarUrl: string;
  isVerified: boolean;
}

export interface Alumni {
  id: string;
  name: string;
  sport: string;
  graduationYear: number;
  profession: string;
  company: string;
  avatarUrl: string;
}

export interface CampusEvent {
  id: string;
  title: string;
  date: string;
  location: string;
  description: string;
  type: 'Workshop' | 'Social' | 'Career Fair' | 'Game Day';
}

export interface NewsArticle {
  id: string;
  title: string;
  author: string;
  date: string;
  snippet: string;
  imageUrl: string;
}
