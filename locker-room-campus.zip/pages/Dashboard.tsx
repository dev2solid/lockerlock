
import React from 'react';
import { events, news } from '../services/dataService';
import EventCard from '../components/EventCard';
import NewsCard from '../components/NewsCard';
import { useAuth } from '../hooks/useAuth';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const upcomingEvents = events.slice(0, 2);
  const recentNews = news.slice(0, 2);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-white">Welcome back, {user?.name.split(' ')[0]}!</h2>
        <p className="mt-1 text-slate-400">Here's what's happening on campus.</p>
      </div>

      <section>
        <h3 className="text-xl font-semibold text-white mb-4">Upcoming Events</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {upcomingEvents.map(event => <EventCard key={event.id} event={event} />)}
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold text-white mb-4">Latest News</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {recentNews.map(article => <NewsCard key={article.id} article={article} />)}
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
