
import React from 'react';
import { news } from '../services/dataService';
import NewsCard from '../components/NewsCard';
import type { NewsArticle } from '../types';

const News: React.FC = () => {
  return (
    <div className="space-y-6">
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {news.map((article: NewsArticle) => (
          <NewsCard key={article.id} article={article} />
        ))}
       </div>
    </div>
  );
};

export default News;
