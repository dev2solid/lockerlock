
import React, { useState, useMemo } from 'react';
import { athletes } from '../services/dataService';
import AthleteCard from '../components/AthleteCard';
import type { Athlete } from '../types';

const Athletes: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSport, setFilterSport] = useState('All');

  const uniqueSports = ['All', ...Array.from(new Set(athletes.map(a => a.sport)))];

  const filteredAthletes = useMemo(() => {
    return athletes.filter(athlete => {
      const nameMatch = athlete.name.toLowerCase().includes(searchTerm.toLowerCase());
      const sportMatch = filterSport === 'All' || athlete.sport === filterSport;
      return nameMatch && sportMatch;
    });
  }, [searchTerm, filterSport]);

  return (
    <div className="space-y-6">
      <div className="bg-slate-800 p-4 rounded-lg flex items-center gap-4">
          <input
            type="text"
            placeholder="Search by name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-grow bg-slate-700 text-white placeholder-slate-400 rounded-md border-slate-600 focus:ring-sky-500 focus:border-sky-500"
          />
          <select
            value={filterSport}
            onChange={(e) => setFilterSport(e.target.value)}
             className="bg-slate-700 text-white rounded-md border-slate-600 focus:ring-sky-500 focus:border-sky-500"
          >
            {uniqueSports.map(sport => (
              <option key={sport} value={sport}>{sport}</option>
            ))}
          </select>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
        {filteredAthletes.map((athlete: Athlete) => (
          <AthleteCard key={athlete.id} athlete={athlete} />
        ))}
      </div>
    </div>
  );
};

export default Athletes;
