
import React, { useState } from 'react';
import { events } from '../services/dataService';
import EventCard from '../components/EventCard';
import type { CampusEvent } from '../types';

const Events: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<'Upcoming' | 'Past'>('Upcoming');
  const now = new Date();

  const upcomingEvents = events.filter(e => new Date(e.date) >= now);
  const pastEvents = events.filter(e => new Date(e.date) < now);

  const displayedEvents = currentTab === 'Upcoming' ? upcomingEvents : pastEvents;

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-700">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          <button
            onClick={() => setCurrentTab('Upcoming')}
            className={`${
              currentTab === 'Upcoming'
                ? 'border-sky-500 text-sky-400'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-500'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            Upcoming
          </button>
          <button
            onClick={() => setCurrentTab('Past')}
            className={`${
              currentTab === 'Past'
                ? 'border-sky-500 text-sky-400'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-500'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            Past
          </button>
        </nav>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayedEvents.map((event: CampusEvent) => (
          <EventCard key={event.id} event={event} />
        ))}
      </div>
    </div>
  );
};

export default Events;
