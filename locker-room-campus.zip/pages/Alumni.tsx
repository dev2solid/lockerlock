
import React, { useState, useMemo } from 'react';
import { alumni } from '../services/dataService';
import AlumniCard from '../components/AlumniCard';
import type { Alumni } from '../types';

const AlumniPage: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [filterIndustry, setFilterIndustry] = useState('All');
  
    const uniqueIndustries = ['All', ...Array.from(new Set(alumni.map(a => a.profession)))];
  
    const filteredAlumni = useMemo(() => {
      return alumni.filter(alum => {
        const nameMatch = alum.name.toLowerCase().includes(searchTerm.toLowerCase());
        const industryMatch = filterIndustry === 'All' || alum.profession === filterIndustry;
        return nameMatch && industryMatch;
      });
    }, [searchTerm, filterIndustry]);

  return (
    <div className="space-y-6">
        <div className="bg-slate-800 p-4 rounded-lg flex items-center gap-4">
          <input
            type="text"
            placeholder="Search by name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-grow bg-slate-700 text-white placeholder-slate-400 rounded-md border-slate-600 focus:ring-sky-500 focus:border-sky-500"
          />
          <select
            value={filterIndustry}
            onChange={(e) => setFilterIndustry(e.target.value)}
             className="bg-slate-700 text-white rounded-md border-slate-600 focus:ring-sky-500 focus:border-sky-500"
          >
            {uniqueIndustries.map(industry => (
              <option key={industry} value={industry}>{industry}</option>
            ))}
          </select>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
        {filteredAlumni.map((alum: Alumni) => (
          <AlumniCard key={alum.id} alumni={alum} />
        ))}
      </div>
    </div>
  );
};

export default AlumniPage;
